

import { BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import Home from './component/Home'
import Header from './component/Header'
import ProductDetail from './component/ProductDetail'
import Admin from './component/Admin'
function App() {
 

  return (
    <section className='p-8 bg-gradient-to-tr from-white via-gray-100 to-purple-500'>
     
      
    <Router>
    <Header />
     <Routes>

      <Route path='/' element={<Home />} /> 
      <Route path="/products/:id" element={<ProductDetail />} />
      <Route path='/admin' element={<Admin />} /> 
   </Routes>
 </Router>
 

</section>
  )
}

export default App
