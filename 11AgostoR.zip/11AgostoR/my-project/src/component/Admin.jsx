import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AdminPanel() {
  const [productName, setProductName] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [productCategoryId, setProductCategoryId] = useState('');

  const [categories, setCategories] = useState([]);
  //const [selectedCategory, setSelectedCategory] = useState('');

  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchCategories();
    fetchProducts();
  }, []);

  async function fetchCategories() {
        try {
            const response = await axios.get('http://localhost:8080/categories');
            setCategories(response.data);
        } catch (error) {
            console.error('Error fetching categories:', error);
        }
    }

  async function fetchProducts() {
        try {
            const response = await axios.get('http://localhost:8080/');
            setProducts(response.data);
        } catch (error) {
            console.error('Error fetching products:', error);
        }
    }

  async function productSubmit(e) {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:8080/', {
                Name: productName,
                Description: productDescription,
                Price: productPrice,
                CategoryId: productCategoryId,
            });

            if (response.status === 201) {
                fetchProducts();
                setProductName('');
                setProductDescription('');
                setProductPrice('');
                setProductCategoryId('');
            }
        } catch (error) {
            console.error('Error adding product:', error);
        }
    }

  async function productdelete(productId) {
        try {
            const response = await axios.delete(`http://localhost:8080/products/:${productId}`);
            if (response.status == 204) {
                fetchProducts();
            }
        } catch (error) {
            console.error('Error deleting product:', error);
        }
    }

  //  aggiornamento ed eliminazione delle categorie
  async function categoryUpdate(categoryId, updatedCategoryData) {
        try {
            const response = await axios.put(`http://localhost:8080/${categoryId}`, updatedCategoryData);
            if (response.status === 200) {
                fetchCategories();
            }
        } catch (error) {
            console.error('Error updating category:', error);
        }
    }

  async function categoryDelete(categoryId) {
        try {
            const response = await axios.delete(`http://localhost:8080/${categoryId}`);
            if (response.status === 204) {
                fetchCategories();
            }
        } catch (error) {
            console.error('Error deleting category:', error);
        }
    }

  return (
    <div className='flex flex-col justify-center items-center gap-20'>
      <h1 className='my-8 text-6xl font-serif'>Admin Panel</h1>
      <form className='flex shadow-md shadow-black p-4 gap-8' onSubmit={productSubmit}>
        {/* ... form fields ... */}
        <label className='font-serif text-xl'>Product Name:
      <input
        type="text"
        value={productName}
        onChange={(e) => setProductName(e.target.value)}
        required
      />
    </label>
    <br />
    <label  className='font-serif text-xl'>
      Product Description:
      <input
        type="text"
        value={productDescription}
        onChange={(e) => setProductDescription(e.target.value)}
        required
      />
    </label>
    <br />
    <label  className='font-serif text-xl'>
      Product Price:
      <input
        type="number"
        value={productPrice}
        onChange={(e) => setProductPrice(e.target.value)}
        required
      />
    </label>
    <br />
    <label  className='font-serif text-xl'>
      Product Category:
      <select 
        value={productCategoryId}
        onChange={(e) => setProductCategoryId(e.target.value)}
        required
      >
        <option value="" disabled>
          Select a category
        </option>
        {categories.map(category => (
          <option key={category.Id} value={category.Id}>
            {category.Name}
          </option>
        ))}
      </select>
    </label>
        <button className='bg-emerald-500 rounded-xl text-xl p-4 shadow-md shadow-black' type="submit">Add Product</button>
      </form>
      <ul className='flex flex-col shadow-md shadow-black p-8 gap-8'>
        {products.map(product => (
          <li className='p-4 text-2xl font-serif gap-8' key={product.id}>
            {product.Name} - {product.Description} - ${product.Price}
            <div className='flex justify-end '>
            <button className='bg-red-500 p-4 rounded-md' onClick={() => productdelete(product.id)}>Delete</button>
            </div>
            
          </li>
        ))}
      </ul>
      {/*  Categories */}
      <ul className='flex  shadow-md shadow-black p-8 gap-8'>
        {categories.map(category => (
          <li className='text-center font-serif text-xl ' key={category.Id}>
            {category.Name}
            {/* Add/Update */}
            <div className='flex gap-8 p-4'>
            <button className='bg-emerald-500 p-4 rounded-md' onClick={() => categoryUpdate(category.Id, { Name: 'Updated Category' })}>Update</button>
            <button className='bg-red-500 p-4 rounded-md' onClick={() => categoryDelete(category.Id)}>Delete</button>
            </div>
           
          </li>
        ))}
      </ul>
    </div>
  );
}

export default AdminPanel;
