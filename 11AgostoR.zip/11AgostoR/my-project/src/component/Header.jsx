import React from "react";
import { Link } from "react-router-dom";

function Header() {
  return (
    <header className="flex flex-row items-center justify-center gap-12 m-auto w-1/2 p-4 bg-slate-800 rounded-xl">
      <div>
        <Link to="/" className="text-white font-serif text-4xl font-extrabold">
          Ecommerce Digitazon
        </Link>
      </div>
      
      <nav >
        <ul className="flex gap-12">
          <li>
            <Link to="/" className="text-white text-2xl hover:text-sky-200">
              Home
            </Link>
          </li>
          <li>
            <Link to="/admin" className="text-white text-2xl hover:text-emerald-500">
              Admin
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
