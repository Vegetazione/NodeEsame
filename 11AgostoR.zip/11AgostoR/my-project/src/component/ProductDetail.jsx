import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { Link } from 'react-router-dom';

function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await axios.get(`http://localhost:8080/products/${id}`);
        setProduct(response.data);
      } catch (error) {
        console.error('Error fetching product:', error);
      }
    }
    fetchData();
  }, [id]);


  if (!product) {
    return <div>Loading...</div>;
  }

  return (
    <div className='flex flex-col items-center justify-center my-8  gap-8  shadow-md shadow-black p-8   rounded-xl' >
      <h2 className='text-3xl  font-serif font-bold'>Dettagli Articolo</h2>
      <h1 className='text-4xl shadow-md shadow-black rounded-lg p-4 font-medium font-serif'>{product.Name}</h1>
      <p className='text-3xl font-medium'>{product.Description}</p>
      <p className='text-6xl font-medium'>Prezzo: ${product.Price}</p>
      <img src={`/images/${product.id}.jpg`} alt={product.Name} />
      <div>
        <Link to ="/"> 
        <button className='bg-emerald-500 hover:bg-emerald-700 shadow-md shadow-black text-white font-serif font-xl p-6 my-8 rounded-lg' >Torna alla Home</button>
         </Link>
    </div>
    </div>
  );
}

export default ProductDetail;
