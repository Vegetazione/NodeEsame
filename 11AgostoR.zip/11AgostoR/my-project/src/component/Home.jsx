import React from 'react'
import axios from 'axios'
import { useState } from 'react'
import { useEffect } from 'react'
import { Link } from 'react-router-dom'
function Home() {
    const [products,setProducts]= useState([])
    const [categories, setCategories] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState('all');

     useEffect(()=> {
        async function  getData() {
           const obj= await axios.get("http://localhost:8080/")
           const cat= await axios.get("http://localhost:8080/categories")
           console.log(obj);
           console.log(cat);
           setProducts(obj.data)
           setCategories(cat.data)
       }
       getData()
      
       }, [])

       const handleCategoryChange = (event) => {
        setSelectedCategory(event.target.value);
      };
    
      const filteredProducts = selectedCategory === 'all' ? products : products.filter(product => product.CategoryId === selectedCategory);
    

  return (
    <div className='flex flex-col justify-center items-center gap-10 my-4 p-4'>
    <h1 className='text-6xl font-serif'>All Digitazon Products</h1>
    <select className='p-4 rounded-2xl text-3xl' value={selectedCategory} onChange={handleCategoryChange}>
      <option value="all">All Categories</option>
      {categories.map(category => (
        <option  key={category.Id} value={category.Id}>
          {category.Name}
        </option>
      ))}
    </select>
    <ul className='flex w-1/2 gap-16 p-10  flex-wrap'>
      {filteredProducts.map(product => (
        <li className='border shadow-md shadow-black border-black p-4 rounded-xl hover:bg-gray-600 hover:text-white text-3xl' key={product.id}>
          <Link to={`/products/${product.id}`}>{product.Name}</Link>
        </li>
      ))}
    </ul>
  </div>
  )
}

export default Home