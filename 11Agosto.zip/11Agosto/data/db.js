import mongoose from "mongoose";
//url dbATLAS
const url="mongodb+srv://vegetazione:inter123@cluster0.s3v3pbm.mongodb.net/EcommerceData"

//connect
mongoose.connect(url)
.then(()=>console.log("db connected"))
.catch((err)=> console.log(err))


//schema
const productSchema =new mongoose.Schema({
    id:{type: String},
    Name:{type:String, required: true},
    Description:{type: String, required: true },
    img:{type: String},
    Price:{type:Number},
    CategoryId:{type: String },
    
})


 const categorySchema =new mongoose.Schema({
    Id:{type: String, required: true},
    Name:{type:String, required: true},
   
    
    
}) 









//agganciare model
export const Product = mongoose.model("Product", productSchema )
export const Category = mongoose.model("Category", categorySchema )
