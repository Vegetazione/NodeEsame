import express from "express";
import ProductController from "../controller/controller.js";
import CategoryController from "../controller/categoryController.js";
import { Product } from "../data/db.js";
const router = express.Router()

router
.get('/', ProductController.index)
.get('/products/:id', ProductController.selProducts)
.delete('/products/:id', ProductController.delProducts)
.post('/', ProductController.addProducts)
.put('/products/:id', ProductController.update)



///Controllers Category

router.get('/categories', CategoryController.index)
router.get('/categories/:id', CategoryController.selCategories);
router.delete('/categories/:id', CategoryController.delCategories);
router.post('/categories', CategoryController.addCategories);
router.put('/categories/:id', CategoryController.update)





export default router