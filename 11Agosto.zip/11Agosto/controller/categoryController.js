import { Category } from "../data/db.js";


class CategoryController {
  
    static async index(req, res) {
      const obj = await Category.find();
      res.json(obj);
    }

    static async selCategories(req, res) {
      try {
        const categoryId = req.params.id;
        const category = await Category.findOne({ id: categoryId });
        if (!category) {
          return res.status(404).json({ error: 'Category not found' });
        }
        res.json(category);
      } catch (error) {
        res.status(500).json({ error: 'Internal server error' });
      }
    }
  
    static async delCategories(req, res) {
      try {
        const categoryId = req.params.id;
        await Category.findOneAndDelete({ id: categoryId });
        res.sendStatus(204);
      } catch (error) {
        res.status(500).json({ error: 'Internal server error' });
      }
    }
  
    static async addCategories(req, res) {
     
        const v = req.body;
        const addCategory = new Category(v);
        await addCategory.save();
        res.json(addCategory);
      }
  
    static async update(req, res) {
      try {
        const categoryId = req.params.id;
        const { name } = req.body;
        await Category.findOneAndUpdate({ id: categoryId }, { name });
        res.sendStatus(200);
      } catch (error) {
        res.status(500).json({ error: 'Internal server error' });
      }
    }  
   
}

export default CategoryController