import { Product } from "../data/db.js";



class ProductController {
    //Home
    static async index(req, res) {
      const obj = await Product.find();
      res.json(obj);
    }
    //1 product
   static async selProducts(req,res){
    const id= req.params.id
    const product= await Product.findOne({ id })
    res.json(product)
   }
   //elimina
   static async delProducts(req,res){
    const id= req.params.id
    const product= await Product.findByIdAndRemove(id)
    res.json(product)
   }
   //aggiungi
   static async addProducts(req, res) {
    const v = req.body;
    const addProducts = new Product(v);
    await addProducts.save();
    res.json(addProducts);
  }

  //aggiorna
  static async update(req, res) {
    const id = req.params.id;
    const updateData = req.body;
    const updatedProduct = await Product.findByIdAndUpdate(id, updateData, {
      new: true,
    });
    res.json(updatedProduct);
  }
}

export default ProductController